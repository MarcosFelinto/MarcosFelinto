# Kélita Produção

Sistema de gestão de produção, custos, estoque e eficiência, com banco de dados na nuvem (Postgres Neon na Vercel) e sincronização em tempo real entre usuários.

## Estrutura

| Pasta / arquivo | Conteúdo |
| --- | --- |
| `public/index.html` | Aplicação (telas, cálculos, relatórios) — evolução do SISTEMA_PRODUÇÃO_EVOLUIDO_V15 |
| `public/assets/nuvem.js` | Login no servidor, carga do banco, fila de gravação, recebimento das alterações dos outros usuários a cada 3 s, controle de conflito |
| `public/assets/impressao.js` | Impressão e PDF do relatório aberto |
| `public/assets/app.css` | Tailwind compilado + folha de impressão (`@media print`) |
| `public/assets/lib`, `fontawesome` | Bibliotecas locais (Chart.js, SheetJS, jsPDF, AutoTable, Font Awesome) |
| `api/auth.js` | `POST /api/auth` login e troca de senha · `GET /api/auth` renova a sessão |
| `api/db.js` | `GET /api/db` carga por tabela, mudanças desde o cursor, status · `POST /api/db` inclusões, alterações e exclusões |
| `api/_lib/db.js` | Esquema do banco, concorrência otimista por versão, exclusão permanente com marca para os outros navegadores |
| `api/_lib/seguranca.js` | Hash de senha (mesmo algoritmo do sistema) e token de sessão assinado |
| `api/_lib/seed.js` | Base inicial (backup de 29/09/2026), carregada só se o banco estiver vazio |
| `estilo/` | Fonte do CSS (Tailwind) — não é publicada |

## Banco de dados

Tabelas criadas automaticamente na primeira chamada:

- `kp_registros (tabela, id, dados jsonb, versao, seq, criado_em, atualizado_em, atualizado_por)` — um registro por cadastro, produção, movimentação, custo, usuário, configuração e log.
- `kp_exclusoes (tabela, id, seq, excluido_em, excluido_por)` — marca das exclusões para avisar os outros navegadores.
- `kp_seq` — sequência global; cada gravação recebe um número, que é o cursor da sincronização.

A conexão vem da variável `DATABASE_URL` criada pela integração Neon no projeto `kelita-producao`.

## Publicar

Windows: dê dois cliques em `publicar.bat`. Linux/macOS: `./publicar.sh`.
Requer Node.js; na primeira vez a Vercel pede login pelo navegador. Endereço: https://kelita-producao.vercel.app

## Primeiro acesso

O banco começa com os dados do backup de 29/09/2026, inclusive os usuários e senhas que já existiam no sistema.
Se o banco estiver vazio e sem usuários, é criado `admin@fabrica.com` com senha `123456`, e a troca é obrigatória no primeiro acesso.
