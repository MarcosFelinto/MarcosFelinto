// ============================================================================
// Kélita Produção — camada de nuvem (cliente)
// ----------------------------------------------------------------------------
// Substitui o armazenamento local (localStorage) pelo banco de dados na nuvem:
//   · login validado no servidor (/api/auth) — a senha nunca fica no navegador;
//   · carga inicial de todas as tabelas a partir do banco (/api/db?acao=tabela);
//   · cada alteração detectada pelo auditor do sistema (auditarAlteracoes) entra
//     numa fila e é enviada em segundos (POST /api/db) com a versão que o usuário
//     conhecia — se outra pessoa gravou antes, o servidor recusa e devolve o
//     registro atual, que substitui o local (sem sobrescrever o trabalho alheio);
//   · a cada 3 segundos o navegador busca só o que mudou desde o último cursor
//     (/api/db?acao=mudancas), mantendo todos os usuários iguais em tempo real.
// Este arquivo é carregado depois do script principal e redefine as funções de
// persistência e login; as demais telas e cálculos continuam as mesmas.
// ============================================================================

const NUVEM = {
    token: '',
    pronto: false,
    carregadoUmaVez: false,
    cursor: 0,
    versoes: new Map(),          // "TABELA:id" -> versão no servidor
    filaExtra: new Map(),        // CONFIG e LOGS (fora do auditor de tabelas)
    enviando: false,
    reenviar: false,
    timerEnvio: null,
    timerPuxar: null,
    timerRenovar: null,
    erros: 0,
    online: true,
    ultimaSync: null,
    configJSON: '',
    ultimoErro: '',
    precisaRecarregar: false
};
const TABELAS_NUVEM = Object.keys(TABELAS_SYNC).concat(['CONFIG', 'LOGS']);
const NOME_TABELA = { PRODUCAO: 'Ordem de produção', INSUMOS: 'Insumo', FUNCIONARIOS: 'Funcionário', EQUIPES: 'Equipe',
    PRODUTOS: 'Produto', CATEGORIAS: 'Categoria', FICHAS: 'Ficha técnica', CUSTOS: 'Custo adicional',
    ESTOQUE: 'Movimentação de estoque', USUARIOS: 'Usuário', CONFIG: 'Configurações', LOGS: 'Log' };
const CAMPOS_DERIVADOS = ['custoAdicionalAlocado', 'custoTotal', 'custoUnitario'];

// ---------------------------------------------------------------------------
// Avisos na tela (toast) e erros inesperados
// ---------------------------------------------------------------------------
function nuvemAviso(msg, tipo, ms) {
    let box = document.getElementById('nuvemToasts');
    if (!box) {
        box = document.createElement('div');
        box.id = 'nuvemToasts';
        box.className = 'no-print fixed bottom-4 right-4 z-[70] flex flex-col gap-2 max-w-sm';
        document.body.appendChild(box);
    }
    const cores = { ok: 'bg-emerald-600', erro: 'bg-red-600', alerta: 'bg-amber-500', info: 'bg-slate-800' };
    const icones = { ok: 'fa-circle-check', erro: 'fa-circle-exclamation', alerta: 'fa-triangle-exclamation', info: 'fa-circle-info' };
    const t = document.createElement('div');
    t.className = (cores[tipo] || cores.info) + ' text-white text-xs font-semibold px-4 py-3 rounded-lg shadow-lg flex gap-2 items-start';
    t.setAttribute('role', tipo === 'erro' ? 'alert' : 'status');
    t.innerHTML = '<i class="fa-solid ' + (icones[tipo] || icones.info) + ' mt-0.5"></i><span></span>';
    t.querySelector('span').textContent = msg;
    box.appendChild(t);
    setTimeout(() => { t.style.transition = 'opacity .4s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 450); }, ms || (tipo === 'erro' ? 8000 : 4000));
}
window.addEventListener('error', e => {
    if (!e || !e.message || /ResizeObserver|Script error/.test(e.message)) return;
    console.error(e.error || e.message);
    nuvemAviso('Erro inesperado: ' + e.message + '. Se repetir, recarregue a página.', 'erro');
});
window.addEventListener('unhandledrejection', e => {
    const m = (e && e.reason && e.reason.message) || String(e && e.reason || '');
    console.error(e.reason);
    if (m) nuvemAviso('Falha: ' + m, 'erro');
});

function nuvemCarregando(texto) {
    let el = document.getElementById('nuvemCarregando');
    if (!texto) { if (el) el.remove(); return; }
    if (!el) {
        el = document.createElement('div');
        el.id = 'nuvemCarregando';
        el.className = 'no-print fixed inset-0 z-[80] bg-slate-900/80 flex items-center justify-center';
        el.innerHTML = '<div class="bg-white rounded-xl shadow-2xl px-6 py-5 flex items-center gap-3 text-sm font-semibold text-slate-700"><i class="fa-solid fa-cloud-arrow-down text-indigo-600 text-xl animate-pulse"></i><span></span></div>';
        document.body.appendChild(el);
    }
    el.querySelector('span').textContent = texto;
}

// ---------------------------------------------------------------------------
// Chamada à API
// ---------------------------------------------------------------------------
async function nuvemApi(metodo, caminho, corpo) {
    let r;
    try {
        r = await fetch(caminho, {
            method: metodo,
            headers: Object.assign({ 'Content-Type': 'application/json' }, NUVEM.token ? { Authorization: 'Bearer ' + NUVEM.token } : {}),
            body: corpo ? JSON.stringify(corpo) : undefined,
            cache: 'no-store'
        });
    } catch (e) {
        throw Object.assign(new Error('Sem conexão com o servidor.'), { rede: true });
    }
    let json = {};
    try { json = await r.json(); } catch (e) { json = {}; }
    if (r.status === 401 && NUVEM.token && caminho.indexOf('/api/auth') !== 0) nuvemSessaoExpirada(json.erro);
    if (!r.ok) throw Object.assign(new Error(json.erro || ('Erro ' + r.status + ' no servidor.')), { status: r.status });
    if (json.servidor) ajustarRelogio(json.servidor);
    return json;
}

// ---------------------------------------------------------------------------
// Persistência: o que era localStorage agora é a fila de envio para a nuvem
// ---------------------------------------------------------------------------
function carregarStorage() { /* dados vêm da nuvem: ver nuvemCarregarTudo() */ }

function salvarStorage() {
    auditarAlteracoes();               // carimba metadados e enfileira o que mudou
    if (!NUVEM.pronto) return;
    const cfg = JSON.stringify(state.config);
    if (cfg !== NUVEM.configJSON) {
        NUVEM.configJSON = cfg;
        NUVEM.filaExtra.set('CONFIG:geral', { op: 'upsert', tabela: 'CONFIG', id: 'geral', dados: { id: 'geral', config: JSON.parse(cfg) } });
    }
    nuvemAgendarEnvio();
}

function registrarLog(acao, entidade, detalhes) {
    const l = {
        id: 'LOG-' + agoraMs().toString(36) + Math.random().toString(36).slice(2, 7),
        dataISO: new Date(agoraMs()).toISOString(),
        data: new Date(agoraMs()).toLocaleString('pt-BR'),
        usuario: (state.currentUser && state.currentUser.name) || 'sistema',
        perfil: (state.currentUser && state.currentUser.role) || '',
        acao: acao, entidade: entidade, detalhes: detalhes
    };
    if (!Array.isArray(state.logs)) state.logs = [];
    state.logs.push(l);
    if (state.logs.length > 3000) state.logs = state.logs.slice(-2000);
    if (NUVEM.pronto) NUVEM.filaExtra.set('LOGS:' + l.id, { op: 'upsert', tabela: 'LOGS', id: l.id, dados: l });
    salvarStorage();
}

// Identificação da sessão (antes ficava no localStorage do computador).
const NUVEM_SESSAO_ID = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : ('S-' + Date.now() + Math.random().toString(36).slice(2));
function obterIdentificacaoSistema() { return NUVEM_SESSAO_ID; }

// Senhas são conferidas no servidor; no navegador só convertemos backups antigos com senha em texto puro.
function migrarSenhas() {
    if (!Array.isArray(state.usuarios)) state.usuarios = [];
    state.usuarios.forEach(u => {
        if (u.senha) { definirSenhaUsuario(u, u.senha); u.precisaTrocarSenha = true; }
        if (u.precisaTrocarSenha === undefined) u.precisaTrocarSenha = false;
    });
}

// Integração antiga com Google Sheets: desativada (a nuvem própria faz esse papel).
function enviarParaGoogleDriveSheets() {}
function iniciarAutoSync() {}
function pararAutoSync() {}
function carregarConfigGoogleNaTela() {}
function sincronizarBidirecional() { return nuvemSincronizarAgora(); }
function atualizarPainelSync() { nuvemAtualizarPainel(false); }

// ---------------------------------------------------------------------------
// Carga inicial
// ---------------------------------------------------------------------------
async function nuvemLerTabelaCompleta(tabela) {
    let depois = 0, registros = [], seqMin = Infinity;
    for (let pagina = 0; pagina < 500; pagina++) {
        const r = await nuvemApi('GET', '/api/db?acao=tabela&tabela=' + encodeURIComponent(tabela) + '&depois=' + depois);
        seqMin = Math.min(seqMin, Number(r.seq) || 0);
        registros = registros.concat(r.registros || []);
        if (!r.mais) break;
        depois = r.ultimoSeq;
    }
    return { tabela, registros, seq: seqMin === Infinity ? 0 : seqMin };
}

function limparControleLocal(reg) {
    const c = Object.assign({}, reg);
    delete c.status_sync; delete c.sync_em; delete c.sistema_id;
    return c;
}

async function nuvemCarregarTudo() {
    nuvemCarregando('Carregando dados da nuvem…');
    try {
        const lidas = await Promise.all(TABELAS_NUVEM.map(t => nuvemLerTabelaCompleta(t)));
        const porTabela = {};
        let cursor = Infinity;
        lidas.forEach(l => { porTabela[l.tabela] = l.registros; cursor = Math.min(cursor, l.seq); });

        aplicandoRemoto = true;
        try {
            NUVEM.versoes.clear();
            NUVEM.filaExtra.clear();
            Object.keys(TABELAS_SYNC).forEach(tab => {
                state[TABELAS_SYNC[tab]] = (porTabela[tab] || []).map(r => {
                    NUVEM.versoes.set(tab + ':' + r.id, r.versao);
                    return Object.assign({}, r.dados, { id: r.id, versao: r.versao, status_sync: 'SINCRONIZADO' });
                });
            });
            const cfg = (porTabela.CONFIG || []).find(r => r.id === 'geral');
            if (cfg) { NUVEM.versoes.set('CONFIG:geral', cfg.versao); if (cfg.dados && cfg.dados.config) mergeProfundo(state.config, cfg.dados.config); }
            state.logs = (porTabela.LOGS || []).map(r => { NUVEM.versoes.set('LOGS:' + r.id, r.versao); return Object.assign({}, r.dados, { id: r.id }); })
                .sort((a, b) => String(a.dataISO || '').localeCompare(String(b.dataISO || '')));
            // Estruturas da antiga sincronização com planilha ficam vazias
            state.googleScriptUrl = '';
            state.filaSync = []; state.excluidos = []; state.changelog = []; state.conflitos = [];
            state.syncMeta = Object.assign({}, state.syncMeta || {}, { ultimoSyncOk: 'nuvem' });
            migrarDados();
        } finally { aplicandoRemoto = false; }

        NUVEM.cursor = cursor === Infinity ? 0 : cursor;
        snapshotSync = montarSnapshot();
        NUVEM.configJSON = JSON.stringify(state.config);
        NUVEM.pronto = true;
        NUVEM.carregadoUmaVez = true;
        NUVEM.ultimaSync = new Date();
        // Custos derivados (rateio) são recalculados com a regra atual; o que mudar é gravado.
        recalcularRateioGlobal();
        salvarStorage();
    } finally {
        nuvemCarregando('');
    }
}

// ---------------------------------------------------------------------------
// Envio das alterações
// ---------------------------------------------------------------------------
function nuvemPendentes() {
    return (state.filaSync || []).filter(f => f.status === 'PENDENTE' || f.status === 'ENVIANDO').length + NUVEM.filaExtra.size;
}

function nuvemAgendarEnvio() {
    clearTimeout(NUVEM.timerEnvio);
    NUVEM.timerEnvio = setTimeout(nuvemEnviar, 250);
    nuvemStatus();
}

// O que cada perfil pode gravar (o servidor confere de novo). Alterações fora da permissão —
// como o recálculo de custos de ordens de outras pessoas feito no celular da funcionária —
// ficam só na tela dela e não viram avisos de erro.
function nuvemPodeGravar(tabela, operacao, reg) {
    const perfil = state.currentUser && state.currentUser.role;
    if (perfil === 'ADMIN') return true;
    if (tabela === 'USUARIOS' || tabela === 'CONFIG') return false;
    if (perfil !== 'OPERADOR') return true;
    if (tabela === 'LOGS') return true;
    if (operacao === 'DELETE') return false;
    if (tabela === 'INSUMOS' || tabela === 'ESTOQUE') return true;
    if (tabela === 'PRODUCAO') {
        const meu = typeof meuFuncionarioId === 'function' ? meuFuncionarioId() : '';
        return !!(meu && reg && (reg.funcionarioIds || []).includes(meu));
    }
    return false;
}

function nuvemMontarOps() {
    const ops = [];
    (state.filaSync || []).forEach(f => {
        if (f.status !== 'PENDENTE') return;
        const chave = f.tabela + ':' + f.registroId;
        if (f.operacao === 'DELETE') {
            if (!nuvemPodeGravar(f.tabela, 'DELETE')) { f.status = 'DESCARTADO'; return; }
            ops.push({ fila: f, chave, payload: { op: 'delete', tabela: f.tabela, id: f.registroId } });
        } else {
            const lista = state[TABELAS_SYNC[f.tabela]] || [];
            const reg = lista.find(r => r.id === f.registroId);
            if (!reg) { f.status = 'DESCARTADO'; return; }
            if (!nuvemPodeGravar(f.tabela, 'UPSERT', reg)) { f.status = 'DESCARTADO'; return; }
            ops.push({ fila: f, chave, payload: { op: 'upsert', tabela: f.tabela, id: f.registroId,
                base: NUVEM.versoes.get(chave) || 0, dados: limparControleLocal(JSON.parse(JSON.stringify(reg))) } });
        }
        f.status = 'ENVIANDO';
    });
    NUVEM.filaExtra.forEach((o, chave) => {
        if (!nuvemPodeGravar(o.tabela, o.op === 'delete' ? 'DELETE' : 'UPSERT', o.dados)) return;
        ops.push({ extra: chave, chave, payload: Object.assign({}, o, { base: o.tabela === 'LOGS' ? 0 : (NUVEM.versoes.get(chave) || 0) }) });
    });
    NUVEM.filaExtra.clear();
    state.filaSync = (state.filaSync || []).filter(f => f.status === 'PENDENTE' || f.status === 'ENVIANDO');
    return ops;
}

async function nuvemEnviar() {
    if (!NUVEM.pronto || !NUVEM.token) return;
    if (NUVEM.enviando) { NUVEM.reenviar = true; return; }
    const ops = nuvemMontarOps();
    if (!ops.length) { nuvemStatus(); return; }
    NUVEM.enviando = true;
    nuvemStatus();
    let falhou = false;
    try {
        for (let i = 0; i < ops.length; i += 400) {
            const lote = ops.slice(i, i + 400);
            let resp;
            try {
                resp = await nuvemApi('POST', '/api/db', { ops: lote.map(o => o.payload) });
            } catch (e) {
                // devolve à fila o que não foi confirmado
                ops.slice(i).forEach(o => {
                    if (o.fila) o.fila.status = 'PENDENTE';
                    else if (o.extra && !NUVEM.filaExtra.has(o.extra)) NUVEM.filaExtra.set(o.extra, { op: o.payload.op, tabela: o.payload.tabela, id: o.payload.id, dados: o.payload.dados });
                });
                // um registro com mais de uma entrada na fila: fica só a mais nova
                const vistos = new Set();
                state.filaSync = state.filaSync.slice().reverse().filter(f => { const k = f.tabela + ':' + f.registroId; if (vistos.has(k)) return false; vistos.add(k); return true; }).reverse();
                throw e;
            }
            nuvemProcessarResultados(lote, resp.resultados || []);
        }
        NUVEM.erros = 0; NUVEM.online = true; NUVEM.ultimaSync = new Date(); NUVEM.ultimoErro = '';
    } catch (e) {
        falhou = true;
        NUVEM.erros++; NUVEM.online = !e.rede; NUVEM.ultimoErro = e.message;
        if (e.status !== 401) setTimeout(nuvemEnviar, Math.min(30000, 2000 * Math.pow(2, NUVEM.erros)));
    } finally {
        NUVEM.enviando = false;
        if (NUVEM.reenviar && !falhou) { NUVEM.reenviar = false; nuvemAgendarEnvio(); }
        nuvemStatus();
    }
}

function nuvemDescricao(tabela, dados, id) {
    const nome = dados && (dados.nome || dados.descricao || dados.tipo || dados.email);
    return (NOME_TABELA[tabela] || tabela) + ' ' + (nome ? '"' + nome + '"' : id);
}

// Diferença só nos custos derivados (recalculados por todos): conflito silencioso.
function nuvemSoDerivados(local, remoto) {
    if (!local || !remoto) return false;
    const limpa = r => { const c = limparControleLocal(r); CAMPOS_DERIVADOS.concat(CAMPOS_META).forEach(k => delete c[k]); return impressaoRegistro(c); };
    return limpa(local) === limpa(remoto);
}

function nuvemProcessarResultados(lote, resultados) {
    const porChave = new Map();
    resultados.forEach(r => porChave.set(r.tabela + ':' + r.id, r));
    const avisos = [];
    const reenviarMesclados = [];
    let mudouLocal = false;
    aplicandoRemoto = true;
    try {
        lote.forEach(o => {
            const r = porChave.get(o.chave);
            const tabela = o.payload.tabela, id = o.payload.id;
            if (o.fila) state.filaSync = state.filaSync.filter(f => f !== o.fila);
            if (!r) return;
            if (r.ok) {
                if (r.excluido) { NUVEM.versoes.delete(o.chave); return; }
                NUVEM.versoes.set(o.chave, r.versao);
                const lista = state[TABELAS_SYNC[tabela]];
                const reg = lista && lista.find(x => x.id === id);
                if (reg) { reg.versao = r.versao; reg.status_sync = 'SINCRONIZADO'; }
                return;
            }
            // Recusado: o banco tem uma versão mais nova (outro usuário) ou o registro foi excluído.
            const outraPendente = (state.filaSync || []).some(f => f.tabela === tabela && f.registroId === id);
            state.filaSync = (state.filaSync || []).filter(f => !(f.tabela === tabela && f.registroId === id));
            if (r.motivo === 'versao' && r.atual) {
                NUVEM.versoes.set(o.chave, r.atual.versao);
                if (tabela === 'CONFIG') {
                    mergeProfundo(state.config, (r.atual.dados && r.atual.dados.config) || {});
                    NUVEM.configJSON = JSON.stringify(state.config);
                    avisos.push('As configurações foram alteradas por outro usuário; a versão mais recente foi carregada.');
                } else {
                    const lista = state[TABELAS_SYNC[tabela]] || [];
                    const i = lista.findIndex(x => x.id === id);
                    const remoto = Object.assign({}, r.atual.dados, { id, versao: r.atual.versao, status_sync: 'SINCRONIZADO' });
                    // Duas pessoas mexendo na mesma comanda ao mesmo tempo (etapas): junta as duas e reenvia
                    const mesclado = tabela === 'PRODUCAO' && typeof mesclarComanda === 'function' ? mesclarComanda(o.payload.dados, remoto) : null;
                    if (mesclado) {
                        if (i >= 0) lista[i] = mesclado; else lista.push(mesclado);
                        reenviarMesclados.push(id); mudouLocal = true; return;
                    }
                    const silencioso = i >= 0 && nuvemSoDerivados(lista[i], remoto) && !outraPendente;
                    if (i >= 0) lista[i] = remoto; else lista.push(remoto);
                    if (!silencioso) avisos.push(nuvemDescricao(tabela, remoto, id) + ' foi alterado(a) por outro usuário antes. A versão mais recente foi carregada — confira e refaça sua alteração, se necessário.');
                }
                mudouLocal = true;
            } else if (r.motivo === 'excluido') {
                NUVEM.versoes.delete(o.chave);
                const lista = state[TABELAS_SYNC[tabela]];
                if (lista) { const i = lista.findIndex(x => x.id === id); if (i >= 0) lista.splice(i, 1); }
                avisos.push(nuvemDescricao(tabela, o.payload.dados, id) + ' foi excluído(a) por outro usuário; a alteração não foi gravada.');
                mudouLocal = true;
            } else if (r.motivo === 'permissao') {
                avisos.push('Seu perfil não tem permissão para alterar ' + (NOME_TABELA[tabela] || tabela).toLowerCase() + '. A alteração foi descartada.');
                NUVEM.precisaRecarregar = true;
            } else {
                avisos.push('Não foi possível gravar ' + nuvemDescricao(tabela, o.payload.dados, id) + '.');
            }
        });
        if (mudouLocal) recalcularRateioGlobal();
    } finally { aplicandoRemoto = false; }
    if (mudouLocal) { snapshotSync = montarSnapshot(); renderizarSeSeguro({ atualizados: 1 }); }
    if (reenviarMesclados.length) { reenviarMesclados.forEach(id => enfileirarSync('PRODUCAO', id, 'UPSERT')); nuvemAgendarEnvio(); }
    avisos.slice(0, 4).forEach(a => nuvemAviso(a, 'alerta', 9000));
    if (avisos.length > 4) nuvemAviso('Mais ' + (avisos.length - 4) + ' registro(s) foram atualizados por outros usuários.', 'alerta', 9000);
    if (NUVEM.precisaRecarregar) { NUVEM.precisaRecarregar = false; nuvemRecarregarTudo(true); }
}

// ---------------------------------------------------------------------------
// Recebimento das alterações dos outros usuários (tempo real)
// ---------------------------------------------------------------------------
async function nuvemPuxar() {
    for (let i = 0; i < 20; i++) {
        const r = await nuvemApi('GET', '/api/db?acao=mudancas&desde=' + NUVEM.cursor);
        nuvemAplicarMudancas(r);
        NUVEM.cursor = Number(r.seq) || NUVEM.cursor;
        if (!r.mais) break;
    }
}

function nuvemAplicarMudancas(r) {
    const alterados = r.alterados || [], excluidos = r.excluidos || [];
    if (!alterados.length && !excluidos.length) return;
    const pendentes = new Set((state.filaSync || []).map(f => f.tabela + ':' + f.registroId));
    NUVEM.filaExtra.forEach((v, k) => pendentes.add(k));
    let mudou = false, recalcular = false, configMudou = false;
    aplicandoRemoto = true;
    try {
        alterados.forEach(x => {
            const chave = x.tabela + ':' + x.id;
            if ((NUVEM.versoes.get(chave) || 0) >= x.versao) return;      // já conhecido (inclui as minhas gravações)
            if (pendentes.has(chave)) return;                               // há alteração local a caminho: o envio resolve
            NUVEM.versoes.set(chave, x.versao);
            if (x.tabela === 'CONFIG') {
                if (x.dados && x.dados.config) { mergeProfundo(state.config, x.dados.config); NUVEM.configJSON = JSON.stringify(state.config); configMudou = true; mudou = true; }
                return;
            }
            if (x.tabela === 'LOGS') {
                if (!state.logs.some(l => l.id === x.id)) { state.logs.push(Object.assign({}, x.dados, { id: x.id })); mudou = true; }
                return;
            }
            const lista = state[TABELAS_SYNC[x.tabela]];
            if (!lista) return;
            const dados = Object.assign({}, x.dados, { id: x.id, versao: x.versao, status_sync: 'SINCRONIZADO' });
            const i = lista.findIndex(o => o.id === x.id);
            if (i >= 0) lista[i] = dados; else lista.push(dados);
            mudou = true;
            if (x.tabela === 'PRODUCAO' || x.tabela === 'CUSTOS') recalcular = true;
            if (x.tabela === 'USUARIOS' && state.currentUser && x.id === state.currentUser.id) nuvemConferirMeuUsuario(dados);
        });
        excluidos.forEach(x => {
            const chave = x.tabela + ':' + x.id;
            if (!NUVEM.versoes.has(chave) && !(state[TABELAS_SYNC[x.tabela]] || []).some(o => o.id === x.id)) return;
            NUVEM.versoes.delete(chave);
            state.filaSync = (state.filaSync || []).filter(f => !(f.tabela === x.tabela && f.registroId === x.id));
            const lista = state[TABELAS_SYNC[x.tabela]];
            if (lista) { const i = lista.findIndex(o => o.id === x.id); if (i >= 0) { lista.splice(i, 1); mudou = true; } }
            if (x.tabela === 'PRODUCAO' || x.tabela === 'CUSTOS') recalcular = true;
        });
        if (recalcular) recalcularRateioGlobal();
    } finally { aplicandoRemoto = false; }
    if (mudou) {
        snapshotSync = montarSnapshot();
        if (configMudou && document.querySelector('#configTab.active')) carregarConfigNaTela();
        renderizarSeSeguro({ atualizados: 1 });
    }
}

function nuvemConferirMeuUsuario(u) {
    if (u.status !== 'ATIVO') {
        alert('Seu usuário foi bloqueado pelo administrador. A sessão será encerrada.');
        sessionStorage.removeItem('kp_token');
        location.reload();
        return;
    }
    if (u.perfil && u.perfil !== state.currentUser.role) {
        state.currentUser.role = u.perfil;
        aplicarPermissoesMenu(u.perfil);
        nuvemAviso('Seu perfil de acesso foi alterado para ' + u.perfil + '.', 'info');
    }
}

// Redesenha só quando ninguém está digitando ou com uma janela aberta.
let renderPendentePosSync = false;
function renderizarSeSeguro(resumo) {
    const modalAberto = Array.from(document.querySelectorAll('.modal-overlay')).some(m => !m.classList.contains('hidden'));
    const ativo = document.activeElement;
    const digitando = ativo && ['INPUT', 'SELECT', 'TEXTAREA'].includes(ativo.tagName);
    if (modalAberto || digitando) { renderPendentePosSync = true; atualizarActiveCountBadge(); return; }
    renderPendentePosSync = false;
    renderizarTudo();
}
function verificarRenderPendente() {
    if (!renderPendentePosSync) return;
    const modalAberto = Array.from(document.querySelectorAll('.modal-overlay')).some(m => !m.classList.contains('hidden'));
    const ativo = document.activeElement;
    if (modalAberto || (ativo && ['INPUT', 'SELECT', 'TEXTAREA'].includes(ativo.tagName))) return;
    renderPendentePosSync = false;
    renderizarTudo();
}

function nuvemAgendarPuxar(ms) {
    clearTimeout(NUVEM.timerPuxar);
    NUVEM.timerPuxar = setTimeout(nuvemCicloPuxar, ms);
}
async function nuvemCicloPuxar() {
    if (!NUVEM.pronto) return;
    try {
        if (nuvemPendentes() && !NUVEM.enviando) await nuvemEnviar();
        await nuvemPuxar();
        NUVEM.erros = 0; NUVEM.online = true; NUVEM.ultimaSync = new Date(); NUVEM.ultimoErro = '';
    } catch (e) {
        NUVEM.erros++; NUVEM.online = !e.rede; NUVEM.ultimoErro = e.message;
    }
    nuvemStatus();
    const base = document.hidden ? 15000 : 3000;
    nuvemAgendarPuxar(NUVEM.erros ? Math.min(30000, base * Math.pow(2, Math.min(NUVEM.erros, 4))) : base);
}
document.addEventListener('visibilitychange', () => { if (!document.hidden && NUVEM.pronto) nuvemAgendarPuxar(150); });
window.addEventListener('online', () => { if (NUVEM.pronto) { nuvemAgendarPuxar(100); nuvemEnviar(); } });
window.addEventListener('beforeunload', e => {
    if (NUVEM.pronto && nuvemPendentes()) { e.preventDefault(); e.returnValue = 'Há alterações ainda não gravadas na nuvem.'; return e.returnValue; }
});

// ---------------------------------------------------------------------------
// Indicador de situação (cabeçalho) e painel em Configurações
// ---------------------------------------------------------------------------
function nuvemStatus() {
    const ponto = document.getElementById('nuvemStatusPonto'), texto = document.getElementById('nuvemStatusTexto');
    if (!ponto || !texto) return;
    const pend = nuvemPendentes();
    let cor = 'bg-emerald-400', msg = 'Nuvem · sincronizado';
    if (!NUVEM.pronto) { cor = 'bg-slate-400'; msg = 'Conectando…'; }
    else if (!NUVEM.online || NUVEM.erros) { cor = 'bg-red-500'; msg = 'Sem conexão' + (pend ? ' · ' + pend + ' pendente(s)' : ''); }
    else if (NUVEM.enviando || pend) { cor = 'bg-amber-400 animate-pulse'; msg = 'Salvando…'; }
    else if (NUVEM.ultimaSync) msg = 'Nuvem · ' + NUVEM.ultimaSync.toLocaleTimeString('pt-BR');
    ponto.className = 'w-2.5 h-2.5 rounded-full ' + cor;
    texto.textContent = msg;
    document.getElementById('nuvemStatus').title = NUVEM.ultimoErro ? ('Último erro: ' + NUVEM.ultimoErro) : 'Clique para sincronizar agora';
}

async function nuvemAtualizarPainel(detalhe) {
    const box = document.getElementById('painelNuvemResumo');
    if (!box) return;
    const card = (t, v, cls) => '<div class="p-3 rounded-lg border bg-slate-50"><p class="text-[10px] uppercase font-bold text-slate-400">' + t + '</p><p class="font-bold ' + (cls || 'text-slate-700') + '">' + v + '</p></div>';
    box.innerHTML = card('Banco de dados', 'Postgres (Neon) · Vercel')
        + card('Situação', NUVEM.online && !NUVEM.erros ? 'Conectado' : 'Sem conexão', NUVEM.online && !NUVEM.erros ? 'text-emerald-600' : 'text-red-600')
        + card('Última sincronização', NUVEM.ultimaSync ? NUVEM.ultimaSync.toLocaleString('pt-BR') : '—')
        + card('Alterações a enviar', String(nuvemPendentes()));
    if (!detalhe) return;
    const alvo = document.getElementById('painelNuvemTabelas');
    alvo.innerHTML = '<p class="text-xs text-slate-400">Consultando o banco…</p>';
    try {
        const r = await nuvemApi('GET', '/api/db?acao=status');
        alvo.innerHTML = '<div class="overflow-x-auto"><table class="w-full text-left text-xs text-slate-600 mt-2"><thead class="bg-slate-50 uppercase text-slate-400 border-b"><tr><th class="p-2">Tabela</th><th class="p-2">Registros</th><th class="p-2">Última alteração</th></tr></thead><tbody>'
            + r.porTabela.map(t => '<tr class="border-b"><td class="p-2 font-bold">' + esc(NOME_TABELA[t.tabela] || t.tabela) + '</td><td class="p-2">' + fmtNum(t.total, 0) + '</td><td class="p-2">' + (t.ultima ? new Date(t.ultima).toLocaleString('pt-BR') : '—') + '</td></tr>').join('')
            + '</tbody></table></div><p class="text-[11px] text-slate-400 mt-2">Espaço ocupado: ' + fmtNum(r.bytes / 1048576, 2) + ' MB · cursor ' + r.seq + '</p>';
    } catch (e) { alvo.innerHTML = '<p class="text-xs text-red-600">' + esc(e.message) + '</p>'; }
}

async function nuvemSincronizarAgora() {
    if (!NUVEM.pronto) return;
    try {
        await nuvemEnviar();
        await nuvemPuxar();
        NUVEM.erros = 0; NUVEM.online = true; NUVEM.ultimaSync = new Date();
        nuvemAviso('Tudo sincronizado com a nuvem.', 'ok', 2500);
    } catch (e) { nuvemAviso('Não foi possível sincronizar: ' + e.message, 'erro'); }
    nuvemStatus();
    nuvemAtualizarPainel(false);
}

async function nuvemRecarregarTudo(silencioso) {
    if (!NUVEM.pronto) return;
    try {
        await nuvemEnviar();
        await nuvemCarregarTudo();
        carregarConfigNaTela();
        renderizarTudo();
        if (!silencioso) nuvemAviso('Dados recarregados da nuvem.', 'ok', 2500);
    } catch (e) { nuvemAviso('Falha ao recarregar: ' + e.message, 'erro'); }
}

// ---------------------------------------------------------------------------
// Login, sessão e saída
// ---------------------------------------------------------------------------
function pedirNovaSenha(email) {
    for (let i = 0; i < 3; i++) {
        const nova = prompt('Primeiro acesso de ' + email + '.\nDefina uma nova senha (mínimo 6 caracteres):');
        if (nova === null) return '';
        if ((nova || '').length < 6) { alert('A senha precisa ter pelo menos 6 caracteres.'); continue; }
        const conf = prompt('Confirme a nova senha:');
        if (conf !== nova) { alert('As senhas não conferem.'); continue; }
        return nova;
    }
    return '';
}

let registrarLogDepois = null;
async function realizarLogin() {
    const email = (document.getElementById('loginEmail').value || '').trim().toLowerCase();
    const senha = document.getElementById('loginSenha').value;
    const erroEl = document.getElementById('loginErro');
    const btn = document.getElementById('btnEntrar');
    erroEl.classList.add('hidden');
    if (btn) { btn.disabled = true; btn.classList.add('opacity-60'); }
    try {
        let r = await nuvemApi('POST', '/api/auth', { acao: 'login', email, senha });
        if (r.precisaTrocarSenha) {
            const nova = pedirNovaSenha(email);
            if (!nova) throw new Error('É obrigatório definir uma nova senha no primeiro acesso.');
            r = await nuvemApi('POST', '/api/auth', { acao: 'trocarSenha', email, senhaAtual: senha, novaSenha: nova });
            registrarLogDepois = ['SENHA', 'USUARIO', 'Senha definida no primeiro acesso (' + email + ')'];
        }
        document.getElementById('loginSenha').value = '';
        await nuvemIniciarSessao(r.token, r.usuario);
    } catch (e) {
        erroEl.innerText = e.message || 'Não foi possível entrar.';
        erroEl.classList.remove('hidden');
    } finally {
        if (btn) { btn.disabled = false; btn.classList.remove('opacity-60'); }
    }
}

async function nuvemIniciarSessao(token, usuario) {
    const reentrada = NUVEM.carregadoUmaVez;
    NUVEM.token = token;
    sessionStorage.setItem('kp_token', token);
    state.currentUser = { id: usuario.id, name: usuario.nome, role: usuario.perfil, email: usuario.email, funcionarioId: usuario.funcionarioId || '' };
    if (reentrada && nuvemPendentes()) { NUVEM.pronto = true; await nuvemEnviar(); }
    await nuvemCarregarTudo();
    const PERFIL_NOME = { ADMIN: 'Administrador', PRODUCAO: 'Operador de Produção', ESTOQUE: 'Operador de Estoque', OPERADOR: 'Funcionária(o)' };
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('userDisplayName').innerText = usuario.nome;
    document.getElementById('userRoleBadge').innerText = PERFIL_NOME[usuario.perfil] || usuario.perfil;
    aplicarPermissoesMenu(usuario.perfil);
    carregarConfigNaTela();
    if (!reentrada) registrarLog('LOGIN', 'SISTEMA', 'Acesso realizado como ' + usuario.perfil + ' (' + usuario.email + ')');
    if (registrarLogDepois) { registrarLog.apply(null, registrarLogDepois); registrarLogDepois = null; }
    renderizarTudo();
    nuvemStatus();
    nuvemAgendarPuxar(3000);
    clearInterval(NUVEM.timerRenovar);
    NUVEM.timerRenovar = setInterval(async () => {
        try { const r = await nuvemApi('GET', '/api/auth'); NUVEM.token = r.token; sessionStorage.setItem('kp_token', r.token); } catch (e) {}
    }, 4 * 3600 * 1000);
}

function nuvemSessaoExpirada(msg) {
    if (!NUVEM.pronto) return;
    NUVEM.pronto = false;
    clearTimeout(NUVEM.timerPuxar);
    sessionStorage.removeItem('kp_token');
    const erroEl = document.getElementById('loginErro');
    erroEl.innerText = (msg || 'Sua sessão expirou.') + ' Entre novamente — suas alterações pendentes serão enviadas.';
    erroEl.classList.remove('hidden');
    document.getElementById('loginEmail').value = (state.currentUser && state.currentUser.email) || '';
    document.getElementById('loginScreen').classList.remove('hidden');
    nuvemStatus();
}

async function logout() {
    try {
        registrarLog('LOGOUT', 'SISTEMA', 'Sessão encerrada');
        clearTimeout(NUVEM.timerEnvio);
        await nuvemEnviar();
    } catch (e) {}
    NUVEM.pronto = false;
    sessionStorage.removeItem('kp_token');
    location.reload();
}

// ---------------------------------------------------------------------------
// Backup: restaurar envia o conteúdo do arquivo para a nuvem
// ---------------------------------------------------------------------------
function restaurarBackupJSON(ev) {
    const file = ev.target.files[0];
    ev.target.value = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (e) {
        let parsed;
        try { parsed = JSON.parse(e.target.result); } catch (err) { alert('Arquivo inválido.'); return; }
        if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.produtos)) { alert('Arquivo não parece ser um backup deste sistema.'); return; }
        const resumo = Object.keys(TABELAS_SYNC).map(t => (NOME_TABELA[t] || t) + ': ' + ((parsed[TABELAS_SYNC[t]] || []).length)).join('\n');
        if (!confirm('Restaurar este backup na nuvem?\n\n' + resumo + '\n\nOs dados atuais serão SUBSTITUÍDOS para todos os usuários (registros que não estão no arquivo serão excluídos). Recomenda-se exportar um backup antes.')) return;
        try {
            Object.keys(TABELAS_SYNC).forEach(t => {
                const k = TABELAS_SYNC[t];
                if (!Array.isArray(parsed[k])) return;
                let lista = parsed[k].filter(r => r && r.id).map(limparControleLocal);
                // o próprio usuário logado nunca é removido por uma restauração
                if (t === 'USUARIOS' && state.currentUser && !lista.some(u => u.id === state.currentUser.id)) {
                    const eu = state.usuarios.find(u => u.id === state.currentUser.id);
                    if (eu) lista.push(eu);
                }
                state[k] = lista;
            });
            if (parsed.config) mergeProfundo(state.config, parsed.config);
            if (Array.isArray(parsed.logs)) {
                const ids = new Set(state.logs.map(l => l.id));
                parsed.logs.forEach((l, i) => {
                    const c = Object.assign({}, l);
                    if (!c.id) c.id = 'LOG-REST-' + i + '-' + Math.random().toString(36).slice(2, 6);
                    if (!ids.has(c.id)) { state.logs.push(c); NUVEM.filaExtra.set('LOGS:' + c.id, { op: 'upsert', tabela: 'LOGS', id: c.id, dados: c }); }
                });
            }
            migrarDados();
            recalcularRateioGlobal();
            registrarLog('RESTORE', 'SISTEMA', 'Backup restaurado de arquivo (' + file.name + ')');
            renderizarTudo();
            nuvemAviso('Backup aplicado. Enviando para a nuvem…', 'info');
        } catch (err) {
            console.error(err);
            alert('Falha ao aplicar o backup: ' + err.message);
        }
    };
    reader.onerror = function () { alert('Não foi possível ler o arquivo.'); };
    reader.readAsText(file);
}

// ---------------------------------------------------------------------------
// Inicialização
// ---------------------------------------------------------------------------
window.onload = async function () {
    try {
        // Nada de dados de exemplo na tela: tudo vem do banco depois do login.
        Object.keys(TABELAS_SYNC).forEach(t => { state[TABELAS_SYNC[t]] = []; });
        state.logs = [];
        state.googleScriptUrl = '';
        state.syncMeta = Object.assign({}, state.syncMeta || {}, { ultimoSyncOk: 'nuvem' });
        migrarDados();
        carregarConfigNaTela();
        definirVisaoProducao('kanban');
        iniciarLoopCronometros();
    } catch (e) { console.error('Falha na preparação da tela', e); }
    nuvemStatus();
    const token = sessionStorage.getItem('kp_token');
    if (token) {
        NUVEM.token = token;
        try {
            const r = await nuvemApi('GET', '/api/auth');
            await nuvemIniciarSessao(r.token, r.usuario);
            return;
        } catch (e) {
            sessionStorage.removeItem('kp_token');
            NUVEM.token = '';
            NUVEM.pronto = false;
        }
    }
    document.getElementById('loginScreen').classList.remove('hidden');
    const email = document.getElementById('loginEmail');
    if (email) email.focus();
};
